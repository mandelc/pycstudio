"""Desktop Pygame implementation of the Python Canvas Studio API.

Install the desktop dependency with ``python -m pip install -r
requirements-desktop.txt``. Then run a Python file that imports this module::

    import canvas_studio as studio

    def draw():
        studio.clear("#ffffff")
        studio.circle(studio.mouse_x, studio.mouse_y, 24)

    studio.start(draw)

On desktop, ``start()`` owns the Pygame event loop and returns when the window
closes. Drawing and input helpers are available from the ``canvas_studio``
module just as they are in the browser version.
"""

import importlib
import math
from pathlib import Path


__all__ = [
    "CanvasImage",
    "CanvasSound",
    "arc",
    "background",
    "button",
    "circle",
    "clear",
    "configure_images",
    "configure_sounds",
    "ellipse",
    "get_canvas_height",
    "get_canvas_width",
    "hide_mouse_pointer",
    "image",
    "init",
    "key",
    "key_code",
    "key_code_name",
    "line",
    "load_image",
    "load_sound",
    "mouse_x",
    "mouse_y",
    "pause_sound",
    "play_sound",
    "polygon",
    "rect",
    "reset_transform",
    "rotate",
    "scale",
    "set_canvas_size",
    "show_mouse_pointer",
    "start",
    "stop_sound",
    "text",
    "translate",
]

_canvas_width = 960
_canvas_height = 520
mouse_x = 0
mouse_y = 0
button = None
key = ""
key_code = ""
key_code_name = ""

_pygame = None
_app = None
_callbacks = {}
_image_paths = {}
_sound_paths = {}
_mouse_visible = True


class CanvasImage:
    """A local image loaded by :func:`load_image`."""

    def __init__(self, name, surface):
        self.name = str(name)
        self.surface = surface
        self.width, self.height = surface.get_size()


class CanvasSound:
    """A local sound loaded by :func:`load_sound`."""

    def __init__(self, name, sound):
        self.name = str(name)
        self._sound = sound
        self._channel = None
        self._paused = False


class _PygameCanvas:
    def __init__(self, pygame):
        self.pygame = pygame
        self.screen = pygame.display.set_mode((_canvas_width, _canvas_height))
        self.transform = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
        self.fonts = {}
        self.images = dict(_image_paths)
        self.sounds = dict(_sound_paths)
        pygame.mouse.set_visible(_mouse_visible)

    def color(self, value):
        if isinstance(value, str) and value.startswith("#") and len(value) in (4, 5):
            value = "#" + "".join(character * 2 for character in value[1:])
        try:
            return self.pygame.Color(value)
        except (TypeError, ValueError) as error:
            raise ValueError(f"Invalid color: {value!r}") from error

    def transform_point(self, x, y):
        a, b, c, d, e, f = self.transform
        return a * x + c * y + e, b * x + d * y + f

    def transform_points(self, points):
        return [self.transform_point(x, y) for x, y in points]

    def compose(self, a, b, c, d, e, f):
        current_a, current_b, current_c, current_d, current_e, current_f = (
            self.transform
        )
        self.transform = (
            current_a * a + current_c * b,
            current_b * a + current_d * b,
            current_a * c + current_c * d,
            current_b * c + current_d * d,
            current_a * e + current_c * f + current_e,
            current_b * e + current_d * f + current_f,
        )

    def scale_factors(self):
        a, b, c, d, _, _ = self.transform
        return math.hypot(a, b), math.hypot(c, d)

    def rotation_degrees(self):
        a, b, _, _, _, _ = self.transform
        return -math.degrees(math.atan2(b, a))


def _load_pygame():
    global _pygame
    if _pygame is None:
        try:
            _pygame = importlib.import_module("pygame")
        except ImportError as error:
            raise ImportError(
                "Pygame is required for the desktop canvas. Install it with "
                "'python -m pip install -r requirements-desktop.txt'."
            ) from error
    return _pygame


def _require_app():
    if _app is None:
        raise RuntimeError("Call start() before using drawing functions.")
    return _app


def _normalized_origin(origin, name):
    pair_error = f"{name} must be a normalized (x, y) pair from 0.0 to 1.0."
    values_error = f"{name} values must be between 0.0 and 1.0."
    try:
        values = tuple(origin)
    except TypeError as error:
        raise ValueError(pair_error) from error
    if len(values) != 2:
        raise ValueError(pair_error)
    try:
        values = tuple(float(value) for value in values)
    except (TypeError, ValueError) as error:
        raise ValueError(values_error) from error
    if any(not math.isfinite(value) or not 0 <= value <= 1 for value in values):
        raise ValueError(values_error)
    return values


def _shape_origin(origin, rotate, angle_unit):
    if angle_unit not in ("degrees", "radians"):
        raise ValueError("angle_unit must be 'degrees' or 'radians'.")
    if origin is None:
        return None, None
    origin = _normalized_origin(origin, "origin")
    if rotate is not None and angle_unit == "degrees":
        rotate = math.radians(rotate)
    return origin, rotate


def _shape_rotation(origin, rotate, angle_unit):
    if angle_unit not in ("degrees", "radians"):
        raise ValueError("angle_unit must be 'degrees' or 'radians'.")
    if origin is None or rotate is None:
        return None, None
    return _normalized_origin(origin, "rotation_origin"), (
        math.radians(rotate) if angle_unit == "degrees" else rotate
    )


def _placement(bounds, origin, rotate, anchor=None):
    left, top, width, height = bounds
    if origin is None:
        return (0.0, 0.0), None
    shape_anchor = (left + origin[0] * width, top + origin[1] * height)
    target = shape_anchor if anchor is None else anchor
    offset = (target[0] - shape_anchor[0], target[1] - shape_anchor[1])
    pivot = target if rotate is not None else None
    return offset, pivot


def _map_shape_point(point, offset, pivot, rotation):
    x, y = point
    x += offset[0]
    y += offset[1]
    if pivot is not None:
        dx, dy = x - pivot[0], y - pivot[1]
        cosine, sine = math.cos(rotation), math.sin(rotation)
        x = pivot[0] + dx * cosine - dy * sine
        y = pivot[1] + dx * sine + dy * cosine
    return x, y


def _draw_polygon(points, color, offset=(0.0, 0.0), pivot=None, rotation=None):
    app = _require_app()
    transformed = app.transform_points(
        _map_shape_point(point, offset, pivot, rotation) for point in points
    )
    app.pygame.draw.polygon(
        app.screen,
        app.color(color),
        [(round(x), round(y)) for x, y in transformed],
    )


def clear(color="#ffffff"):
    """Fill the entire canvas with a color."""
    app = _require_app()
    app.screen.fill(app.color(color))


def background(color):
    """Alias for :func:`clear`."""
    clear(color)


def set_canvas_size(width, height):
    """Set the canvas size in pixels using positive integer dimensions."""
    if (
        isinstance(width, bool)
        or not isinstance(width, int)
        or isinstance(height, bool)
        or not isinstance(height, int)
        or width <= 0
        or height <= 0
    ):
        raise ValueError("Canvas width and height must be positive integers.")

    global _canvas_width, _canvas_height
    _canvas_width, _canvas_height = width, height
    if _app is not None:
        _app.screen = _pygame.display.set_mode((width, height))
        _app.transform = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
        _app.screen.fill(_app.color("#ffffff"))


def get_canvas_width():
    """Return the canvas width in pixels."""
    return _canvas_width


def get_canvas_height():
    """Return the canvas height in pixels."""
    return _canvas_height


def translate(x, y):
    """Move the canvas origin by x and y pixels."""
    _require_app().compose(1, 0, 0, 1, x, y)


def rotate(angle, angle_unit="degrees"):
    """Rotate subsequent drawing clockwise by degrees or radians."""
    if angle_unit not in ("degrees", "radians"):
        raise ValueError("angle_unit must be 'degrees' or 'radians'.")
    radians = math.radians(angle) if angle_unit == "degrees" else angle
    cosine, sine = math.cos(radians), math.sin(radians)
    _require_app().compose(cosine, sine, -sine, cosine, 0, 0)


def scale(x, y=None):
    """Scale subsequent drawing horizontally by x and vertically by y."""
    _require_app().compose(x, 0, 0, x if y is None else y, 0, 0)


def reset_transform():
    """Reset translation, rotation, and scaling."""
    _require_app().transform = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def rect(
    x,
    y,
    width,
    height,
    color="#5b56e8",
    *,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw a filled rectangle; by default x and y are its top-left corner."""
    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    bounds = (
        min(x, x + width),
        min(y, y + height),
        abs(width),
        abs(height),
    )
    offset, pivot = _placement(bounds, origin, rotation, (x, y))
    _draw_polygon(
        ((x, y), (x + width, y), (x + width, y + height), (x, y + height)),
        color,
        offset,
        pivot,
        rotation,
    )


def circle(
    x,
    y,
    radius,
    color="#f6c85f",
    *,
    rotation_origin=None,
    rotate=None,
    angle_unit="degrees",
):
    """Draw a filled circle centered at x and y."""
    origin, rotation = _shape_rotation(rotation_origin, rotate, angle_unit)
    radius = max(0, radius)
    segments = max(32, min(256, round(math.tau * max(radius, 1) / 4)))
    points = [
        (
            x + radius * math.cos(index * math.tau / segments),
            y + radius * math.sin(index * math.tau / segments),
        )
        for index in range(segments)
    ]
    bounds = (x - radius, y - radius, radius * 2, radius * 2)
    offset, pivot = _placement(bounds, origin, rotation)
    _draw_polygon(points, color, offset, pivot, rotation)


def ellipse(
    x,
    y,
    width,
    height,
    color="#f6c85f",
    *,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw an ellipse; by default x and y are its bounding-box top-left."""
    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    width, height = max(0, width), max(0, height)
    left, top = x, y
    center_x, center_y = left + width / 2, top + height / 2
    segments = max(32, min(256, round(math.pi * max(width, height) / 4)))
    points = [
        (
            center_x + width / 2 * math.cos(index * math.tau / segments),
            center_y + height / 2 * math.sin(index * math.tau / segments),
        )
        for index in range(segments)
    ]
    offset, pivot = _placement((left, top, width, height), origin, rotation, (x, y))
    _draw_polygon(points, color, offset, pivot, rotation)


def arc(
    x,
    y,
    radius,
    start_angle,
    end_angle,
    color="#39445c",
    width=2,
    *,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw a stroked arc in clockwise order, in degrees by default."""
    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    if angle_unit == "degrees":
        start_angle, end_angle = math.radians(start_angle), math.radians(end_angle)
    radius = max(0, radius)
    span = max(-math.tau, min(math.tau, end_angle - start_angle))
    segments = max(2, min(512, math.ceil(abs(span) * max(radius, 1) / 3)))
    points = [
        (
            x + radius + radius * math.cos(start_angle + span * index / segments),
            y + radius + radius * math.sin(start_angle + span * index / segments),
        )
        for index in range(segments + 1)
    ]
    bounds = (x, y, radius * 2, radius * 2)
    offset, pivot = _placement(bounds, origin, rotation, (x, y))
    app = _require_app()
    points = app.transform_points(
        _map_shape_point(point, offset, pivot, rotation) for point in points
    )
    scale_x, scale_y = app.scale_factors()
    app.pygame.draw.lines(
        app.screen,
        app.color(color),
        False,
        [(round(px), round(py)) for px, py in points],
        max(1, round(max(0, width or 1) * (scale_x + scale_y) / 2)),
    )


def polygon(
    points,
    color="#5b56e8",
    *,
    x=None,
    y=None,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw a polygon, optionally positioning its normalized origin at x, y."""
    try:
        vertices = [tuple(point) for point in points]
    except TypeError as error:
        raise ValueError("polygon() expects a sequence of (x, y) points.") from error
    if len(vertices) < 3 or any(len(point) != 2 for point in vertices):
        raise ValueError("polygon() expects at least three (x, y) points.")
    if (x is None) != (y is None):
        raise ValueError("polygon() requires both x and y when positioning it.")

    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    left = min(point[0] for point in vertices)
    top = min(point[1] for point in vertices)
    width = max(point[0] for point in vertices) - left
    height = max(point[1] for point in vertices) - top
    bounds = (left, top, width, height)
    anchor = (x, y) if x is not None else None
    offset, pivot = _placement(bounds, origin, rotation, anchor)
    _draw_polygon(vertices, color, offset, pivot, rotation)


def line(x1, y1, x2, y2, color="#39445c", width=2):
    """Draw a line between two points."""
    app = _require_app()
    points = app.transform_points(((x1, y1), (x2, y2)))
    scale_x, scale_y = app.scale_factors()
    x_start, y_start = points[0]
    x_end, y_end = points[1]
    delta_x = x_end - x_start
    delta_y = y_end - y_start
    length = math.hypot(delta_x, delta_y)
    if length == 0:
        return

    half_width = max(1, round(max(0, width or 1) * (scale_x + scale_y) / 2)) / 2
    offset_x = -delta_y * half_width / length
    offset_y = delta_x * half_width / length
    app.pygame.draw.polygon(
        app.screen,
        app.color(color),
        [
            (round(x_start + offset_x), round(y_start + offset_y)),
            (round(x_end + offset_x), round(y_end + offset_y)),
            (round(x_end - offset_x), round(y_end - offset_y)),
            (round(x_start - offset_x), round(y_start - offset_y)),
        ],
    )


def _render_text(value, size, color):
    app = _require_app()
    scale_x, scale_y = app.scale_factors()
    font_size = max(1, round(size * (scale_x + scale_y) / 2))
    font = app.fonts.get(font_size)
    if font is None:
        font = app.pygame.font.Font(None, font_size)
        app.fonts[font_size] = font
    lines = str(value).replace("\r\n", "\n").replace("\r", "\n").split("\n")
    rendered = [font.render(item, True, app.color(color)) for item in lines]
    width = max(1, max(surface.get_width() for surface in rendered))
    height = max(1, font.get_linesize() * len(lines))
    surface = app.pygame.Surface((width, height), app.pygame.SRCALPHA)
    for index, line_surface in enumerate(rendered):
        surface.blit(line_surface, (0, index * font.get_linesize()))
    return surface, font.get_ascent()


def text(
    value,
    x,
    y,
    size=20,
    color="#253149",
    align="left",
    *,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw text with an optional alignment and normalized shape origin."""
    if align not in ("left", "center", "right"):
        raise ValueError("align must be 'left', 'center', or 'right'.")
    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    app = _require_app()
    surface, ascent = _render_text(value, size or 20, color)
    scale_x, scale_y = app.scale_factors()
    source_width, source_height = surface.get_size()
    left = x - source_width / 2 if align == "center" else (
        x - source_width if align == "right" else x
    )
    top = y - ascent
    if (scale_x, scale_y) != (1.0, 1.0):
        surface = app.pygame.transform.smoothscale(
            surface,
            (max(1, round(source_width * scale_x)),
             max(1, round(source_height * scale_y))),
        )
    bounds = (left, y, source_width, source_height)
    offset, pivot = _placement(bounds, origin, rotation, (x, y))
    center = _map_shape_point(
        (left + source_width / 2, top + source_height / 2),
        offset,
        pivot,
        rotation,
    )
    center = app.transform_point(*center)
    angle = app.rotation_degrees()
    if rotation is not None:
        angle -= math.degrees(rotation)
    if angle:
        surface = app.pygame.transform.rotate(surface, angle)
    app.screen.blit(surface, surface.get_rect(center=center))


def configure_images(images):
    """Map image names to local file paths for :func:`load_image`."""
    if not hasattr(images, "items"):
        raise TypeError("configure_images() expects a mapping of names to file paths.")
    global _image_paths
    _image_paths = {str(name): Path(path) for name, path in images.items()}
    if _app is not None:
        _app.images = dict(_image_paths)


def _resolve_asset_path(name, configured_paths, asset_folder):
    name = str(name)
    candidates = []
    configured_path = configured_paths.get(name)
    if configured_path is not None:
        candidates.append(Path(configured_path))

    requested_path = Path(name)
    candidates.append(requested_path)
    module_directory = Path(__file__).resolve().parent
    if not requested_path.is_absolute():
        candidates.append(module_directory / requested_path)
        if len(requested_path.parts) == 1:
            candidates.append(module_directory / asset_folder / requested_path)

    checked = set()
    for candidate in candidates:
        key = str(candidate)
        if key not in checked:
            checked.add(key)
            if candidate.is_file():
                return candidate
    return candidates[0]


def load_image(name):
    """Load an image from a local path or a name configured with configure_images()."""
    pygame = _load_pygame()
    image_path = _resolve_asset_path(
        name,
        _app.images if _app is not None else _image_paths,
        "images",
    )
    if not image_path.is_file():
        raise FileNotFoundError(f"No image file found at {str(image_path)!r}.")
    try:
        surface = pygame.image.load(str(image_path))
        if pygame.display.get_surface() is not None:
            surface = surface.convert_alpha()
    except pygame.error as error:
        raise ValueError(f"Unable to load image {str(image_path)!r}: {error}") from error
    return CanvasImage(image_path, surface)


def image(
    image_object,
    x,
    y,
    w,
    h,
    *,
    origin=(0, 0),
    rotate=None,
    angle_unit="degrees",
):
    """Draw a loaded image scaled to w by h pixels."""
    if not isinstance(image_object, CanvasImage):
        raise TypeError("image() expects an image returned by load_image().")
    origin, rotation = _shape_origin(origin, rotate, angle_unit)
    if w == 0 or h == 0:
        return
    app = _require_app()
    scale_x, scale_y = app.scale_factors()
    target_size = (max(1, round(abs(w) * scale_x)), max(1, round(abs(h) * scale_y)))
    surface = app.pygame.transform.smoothscale(image_object.surface, target_size)
    if w < 0 or h < 0:
        surface = app.pygame.transform.flip(surface, w < 0, h < 0)
    bounds = (min(x, x + w), min(y, y + h), abs(w), abs(h))
    offset, pivot = _placement(bounds, origin, rotation, (x, y))
    center = _map_shape_point((x + w / 2, y + h / 2), offset, pivot, rotation)
    center = app.transform_point(*center)
    angle = app.rotation_degrees()
    if rotation is not None:
        angle -= math.degrees(rotation)
    if angle:
        surface = app.pygame.transform.rotate(surface, angle)
    app.screen.blit(surface, surface.get_rect(center=center))


def configure_sounds(sounds):
    """Map sound names to local file paths for :func:`load_sound`."""
    if not hasattr(sounds, "items"):
        raise TypeError("configure_sounds() expects a mapping of names to file paths.")
    global _sound_paths
    _sound_paths = {str(name): Path(path) for name, path in sounds.items()}
    if _app is not None:
        _app.sounds = dict(_sound_paths)


def load_sound(name):
    """Load a local audio file or a name configured with configure_sounds()."""
    pygame = _load_pygame()
    sound_path = _resolve_asset_path(
        name,
        _app.sounds if _app is not None else _sound_paths,
        "sounds",
    )
    if not sound_path.is_file():
        raise FileNotFoundError(f"No sound file found at {str(sound_path)!r}.")
    try:
        if pygame.mixer.get_init() is None:
            pygame.mixer.init()
        sound = pygame.mixer.Sound(str(sound_path))
    except pygame.error as error:
        raise RuntimeError(f"Unable to load sound {str(sound_path)!r}: {error}") from error
    return CanvasSound(sound_path, sound)


def play_sound(sound):
    """Play or resume a sound returned by :func:`load_sound`."""
    if not isinstance(sound, CanvasSound):
        raise TypeError("play_sound() expects a sound returned by load_sound().")
    if sound._paused and sound._channel is not None:
        sound._channel.unpause()
        sound._paused = False
    else:
        if (
            sound._channel is not None
            and sound._channel.get_sound() is sound._sound
        ):
            sound._channel.stop()
        sound._channel = sound._sound.play()
        sound._paused = False


def pause_sound(sound):
    """Pause a sound returned by :func:`load_sound`."""
    if not isinstance(sound, CanvasSound):
        raise TypeError("pause_sound() expects a sound returned by load_sound().")
    if (
        sound._channel is not None
        and sound._channel.get_sound() is sound._sound
        and sound._channel.get_busy()
    ):
        sound._channel.pause()
        sound._paused = True


def stop_sound(sound):
    """Stop a sound and reset it so the next playback starts at the beginning."""
    if not isinstance(sound, CanvasSound):
        raise TypeError("stop_sound() expects a sound returned by load_sound().")
    if (
        sound._channel is not None
        and sound._channel.get_sound() is sound._sound
    ):
        sound._channel.stop()
    sound._channel = None
    sound._paused = False


def hide_mouse_pointer():
    """Hide the mouse pointer while it is over the canvas."""
    global _mouse_visible
    _mouse_visible = False
    if _app is not None:
        _pygame.mouse.set_visible(False)


def show_mouse_pointer():
    """Show the mouse pointer while it is over the canvas."""
    global _mouse_visible
    _mouse_visible = True
    if _app is not None:
        _pygame.mouse.set_visible(True)


def _key_values(event):
    pygame = _pygame
    name = pygame.key.name(event.key)
    unicode_value = getattr(event, "unicode", "")
    key_value = unicode_value if unicode_value and unicode_value.isprintable() else {
        "return": "Enter",
        "backspace": "Backspace",
        "escape": "Escape",
        "space": " ",
        "page up": "PageUp",
        "page down": "PageDown",
        "left": "ArrowLeft",
        "right": "ArrowRight",
        "up": "ArrowUp",
        "down": "ArrowDown",
    }.get(name, name)
    code_map = {
        "backspace": 8, "tab": 9, "return": 13, "escape": 27, "space": 32,
        "page up": 33, "page down": 34, "end": 35, "home": 36,
        "left": 37, "up": 38, "right": 39, "down": 40, "insert": 45,
        "delete": 46, "left shift": 16, "right shift": 16,
        "left ctrl": 17, "right ctrl": 17, "left alt": 18, "right alt": 18,
    }
    numeric_code = code_map.get(name)
    if numeric_code is None:
        if len(name) == 1 and name.isalpha():
            numeric_code = ord(name.upper())
        elif name.startswith("f") and name[1:].isdigit():
            numeric_code = 111 + int(name[1:])
        else:
            numeric_code = event.key
    code_names = {
        "left": "ArrowLeft", "right": "ArrowRight", "up": "ArrowUp",
        "down": "ArrowDown", "left shift": "ShiftLeft",
        "right shift": "ShiftRight", "left ctrl": "ControlLeft",
        "right ctrl": "ControlRight", "left alt": "AltLeft",
        "right alt": "AltRight", "return": "Enter", "backspace": "Backspace",
        "page up": "PageUp", "page down": "PageDown", "space": "Space",
    }
    if name in code_names:
        code_name = code_names[name]
    elif len(name) == 1 and name.isalpha():
        code_name = f"Key{name.upper()}"
    elif len(name) == 1 and name.isdigit():
        code_name = f"Digit{name}"
    elif name.startswith("f") and name[1:].isdigit():
        code_name = f"F{name[1:]}"
    else:
        code_name = name
    return key_value, numeric_code, code_name


def _dispatch_input(name):
    callback = _callbacks.get(name)
    if callback is not None:
        callback()


def _handle_event(event):
    global button, key, key_code, key_code_name
    pygame = _pygame
    if event.type == pygame.QUIT:
        return False
    if event.type == pygame.MOUSEMOTION:
        _set_mouse_position(*event.pos)
    elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
        _set_mouse_position(*event.pos)
        button = {1: 0, 2: 1, 3: 2}.get(event.button, event.button - 1)
        _dispatch_input(
            "mousePressed" if event.type == pygame.MOUSEBUTTONDOWN else "mouseReleased"
        )
    elif event.type in (pygame.KEYDOWN, pygame.KEYUP):
        key, key_code, key_code_name = _key_values(event)
        _dispatch_input("keyPressed" if event.type == pygame.KEYDOWN else "keyReleased")
    return True


def _set_mouse_position(x, y):
    global mouse_x, mouse_y
    mouse_x, mouse_y = x, y


def start(
    draw=None,
    *,
    update=None,
    setup=None,
    mousePressed=None,
    mouseReleased=None,
    keyPressed=None,
    keyReleased=None,
):
    """Start the desktop window and run callbacks until it closes.

    The Pygame event loop runs synchronously on desktop; this function returns
    when the user closes the window. In the browser, the host drives that loop.
    """
    global _app, _callbacks
    callbacks = {
        "draw": draw,
        "update": update,
        "setup": setup,
        "mousePressed": mousePressed,
        "mouseReleased": mouseReleased,
        "keyPressed": keyPressed,
        "keyReleased": keyReleased,
    }
    for name, callback in callbacks.items():
        if callback is not None and not callable(callback):
            raise TypeError(f"{name} must be callable or None.")
    if _app is not None:
        raise RuntimeError("The desktop canvas is already running.")

    pygame = _load_pygame()
    pygame.init()
    pygame.font.init()
    _callbacks = callbacks
    try:
        _app = _PygameCanvas(pygame)
        pygame.display.set_caption("Python Canvas Studio")
        _app.screen.fill(_app.color("#ffffff"))
        clock = pygame.time.Clock()
        if setup is not None:
            setup()
        running = True
        while running:
            for event in pygame.event.get():
                running = _handle_event(event)
                if not running:
                    break
            if not running:
                break
            if update is not None:
                update()
            if draw is not None:
                draw()
            pygame.display.flip()
            clock.tick(60)
    finally:
        _app = None
        _callbacks = {}
        pygame.quit()


init = start
